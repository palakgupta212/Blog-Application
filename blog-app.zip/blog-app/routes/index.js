const express = require('express');
const router = express.Router();
const Post = require('../models/Post');

router.get('/', async (req, res) => {
  try {
    const posts = await Post.find().populate('author').sort({ createdAt: -1 });
    res.render('index', { user: req.session.user, posts });
  } catch (err) {
    res.status(500).send('Server error');
  }
});

router.get('/about', (req, res) => {
  res.render('about', { user: req.session.user });
});

module.exports = router;
