const express = require('express');
const router = express.Router();
const Post = require('../models/Post');

function ensureAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/auth/login');
  next();
}

// Show new post form
router.get('/new', ensureAuth, (req, res) => res.render('posts/new', { user: req.session.user }));

// Create post
router.post('/', ensureAuth, async (req, res) => {
  const { title, body } = req.body;
  try {
    const post = new Post({ author: req.session.user.id, title, body });
    await post.save();
    res.redirect('/');
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Show edit form
router.get('/:id/edit', ensureAuth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.redirect('/');
  if (post.author.toString() !== req.session.user.id) return res.redirect('/');
  res.render('posts/edit', { user: req.session.user, post });
});

// Update post
router.put('/:id', ensureAuth, async (req, res) => {
  const { title, body } = req.body;
  try {
    let post = await Post.findById(req.params.id);
    if (!post) return res.redirect('/');
    if (post.author.toString() !== req.session.user.id) return res.redirect('/');
    post.title = title;
    post.body = body;
    await post.save();
    res.redirect('/');
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Delete post
router.delete('/:id', ensureAuth, async (req, res) => {
  try {
    let post = await Post.findById(req.params.id);
    if (!post) return res.redirect('/');
    if (post.author.toString() !== req.session.user.id) return res.redirect('/');
    await post.remove();
    res.redirect('/');
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// View single post
router.get('/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('author');
    if (!post) return res.redirect('/');
    res.render('posts/show', { user: req.session.user, post });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;
